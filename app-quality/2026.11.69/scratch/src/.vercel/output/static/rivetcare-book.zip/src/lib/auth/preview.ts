/**
 * Shared LIVE-PREVIEW OAuth client (server-only — NEVER import from the client).
 *
 * The sandbox serves each live preview on a dynamic `https://*.grok-sandbox.com`
 * URL, which can't be pre-registered per app. The broker instead exposes ONE
 * shared "preview" client that accepts any
 * `https://*.grok-sandbox.com/api/auth/oauth2/callback/*`
 * (broker: `app-builder-deployer/auth/src/preview-oauth.ts`). The client id and
 * secret come from the environment, not from this file. When deployed the
 * deployer injects a per-app `GROK_AUTH_*` that overrides these (see `server.ts`).
 *
 * These MUST equal the broker's `GROK_PREVIEW_CLIENT_ID` /
 * `GROK_PREVIEW_CLIENT_SECRET`. Set them in the environment. Do not commit
 * the secret. The broker stores only the secret's `base64url(SHA-256)` hash.
 * This is a dedicated, low-privilege client (preview-only, `*.grok-sandbox.com`).
 */
function previewEnv(key: string): string {
  const value = typeof process !== "undefined" ? process.env[key]?.trim() : "";
  return value || "";
}

export const PREVIEW_CLIENT_ID = previewEnv("GROK_PREVIEW_CLIENT_ID") || "grok_preview";
export const PREVIEW_CLIENT_SECRET = previewEnv("GROK_PREVIEW_CLIENT_SECRET");

/** The shared auth broker issuer (OIDC discovery lives under it). */
export const GROK_ISSUER_DEFAULT = "https://auth.grok.me";

/**
 * Host patterns whose callbacks the preview client accepts. Better Auth derives
 * the live preview's real origin from the request host and validates it against
 * this list (wildcard-matched), so the OAuth `redirect_uri` becomes the concrete
 * `https://<preview-host>/api/auth/oauth2/callback/...` the broker allows.
 */
export const PREVIEW_ALLOWED_HOSTS = ["*.grok-sandbox.com"] as const;
